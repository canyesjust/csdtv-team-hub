// Serves the operator panel and exposes a small API. Pushes live status over a
// websocket so the panel updates every second. OBS loads this same URL as a
// Custom Browser Dock.

import express from 'express';
import { WebSocketServer } from 'ws';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export function startServer(cfg, rotator, log) {
  const app = express();
  app.use(express.json());
  app.use(express.static(path.join(__dirname, '..', 'public')));

  app.get('/api/status', (req, res) => {
    res.json({ status: rotator.status(), log: log.recent() });
  });

  app.post('/api/play-now', async (req, res) => {
    await rotator.playNow();
    res.json({ ok: true });
  });

  app.post('/api/play-file', async (req, res) => {
    await rotator.playFile(String(req.body.file || ''));
    res.json({ ok: true });
  });

  app.post('/api/stop', async (req, res) => {
    await rotator.stop();
    res.json({ ok: true });
  });

  app.post('/api/preshow', async (req, res) => {
    if (req.body.on) await rotator.startPreshow();
    else await rotator.stopPreshow();
    res.json({ ok: true });
  });

  app.post('/api/toggle-auto', (req, res) => {
    rotator.setAuto(Boolean(req.body.enabled));
    res.json({ ok: true });
  });

  app.post('/api/reload', (req, res) => {
    rotator.reload();
    res.json({ ok: true });
  });

  const server = http.createServer(app);
  const wss = new WebSocketServer({ server });

  setInterval(() => {
    const payload = JSON.stringify({ status: rotator.status(), log: log.recent() });
    for (const client of wss.clients) {
      if (client.readyState === 1) client.send(payload);
    }
  }, 1000);

  server.listen(cfg.panelPort, () => {
    log.add(`Operator panel at http://127.0.0.1:${cfg.panelPort}`);
  });
}
