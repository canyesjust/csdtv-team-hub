// Entry point. Wires the OBS connection, the rotator module, and the web panel
// together. Add future modules (scheduler, graphics) right here.

import fs from 'node:fs';
import { ObsClient } from './obs.js';
import { Rotator } from './rotator.js';
import { HubSync } from './sync.js';
import { startServer } from './server.js';

const configUrl = new URL('../config.json', import.meta.url);
const cfg = JSON.parse(fs.readFileSync(configUrl));

// Persist config changes made from the panel's Settings.
function saveConfig() {
  fs.writeFileSync(configUrl, JSON.stringify(cfg, null, 2) + '\n');
}

// Simple shared log buffer the panel can read.
const buffer = [];
const log = {
  add(msg) {
    const line = { time: new Date().toLocaleTimeString(), msg };
    buffer.push(line);
    if (buffer.length > 100) buffer.shift();
    console.log(`[${line.time}] ${msg}`);
  },
  recent() {
    return buffer.slice(-30);
  },
};

const obs = new ObsClient(cfg);
obs.on('log', m => log.add(m));

const rotator = new Rotator(cfg, obs);
rotator.on('log', m => log.add(m));

const sync = new HubSync(cfg, rotator);
sync.on('log', m => log.add(m));

startServer(cfg, rotator, log, sync, saveConfig);

await obs.connect();
if (cfg.autoStart) rotator.setAuto(true);

// Keep the local ad folder current with the hub.
if (cfg.autoSyncOnStart !== false) {
  sync.run('missing');
} else {
  sync.checkHub(); // at least show how many are waiting
}
const everyMin = Number(cfg.autoSyncEveryMin || 0);
if (everyMin > 0) {
  setInterval(() => sync.run('missing'), everyMin * 60 * 1000);
}
