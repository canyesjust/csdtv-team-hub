// Entry point. Wires the OBS connection, the rotator module, and the web panel
// together. Add future modules (scheduler, graphics) right here.

import fs from 'node:fs';
import { ObsClient } from './obs.js';
import { Rotator } from './rotator.js';
import { startServer } from './server.js';

const cfg = JSON.parse(fs.readFileSync(new URL('../config.json', import.meta.url)));

// Simple shared log buffer the panel can read.
const buffer = [];
const log = {
  add(msg) {
    const line = { time: new Date().toLocaleTimeString(), msg };
    buffer.push(line);
    if (buffer.length > 100) buffer.shift();
    console.log(`[${line.time}] ${msg}`);
  },
  recent() {
    return buffer.slice(-30);
  },
};

const obs = new ObsClient(cfg);
obs.on('log', m => log.add(m));

const rotator = new Rotator(cfg, obs);
rotator.on('log', m => log.add(m));

startServer(cfg, rotator, log);

await obs.connect();
if (cfg.autoStart) rotator.setAuto(true);
