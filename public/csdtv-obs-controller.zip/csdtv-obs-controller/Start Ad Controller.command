#!/bin/bash
# Double-click launcher for the CSDTV Ad Controller (Mac).
# First run installs dependencies, then it just starts. No terminal needed.

# Always run from this script's own folder, wherever it was moved to.
cd "$(dirname "$0")" || exit 1

echo "==============================================="
echo "  CSDTV Ad Controller"
echo "==============================================="
echo ""

# 1. Find Node. A double-clicked .command starts with a bare PATH, so Node may
# be installed but not on it (common with the nodejs.org installer, Homebrew, or
# nvm). Add the usual install locations and load nvm before giving up.
export PATH="/usr/local/bin:/opt/homebrew/bin:/usr/local/opt/node/bin:$PATH"

# Load nvm if it's how Node was installed.
export NVM_DIR="${NVM_DIR:-$HOME/.nvm}"
if [ -s "$NVM_DIR/nvm.sh" ]; then
  . "$NVM_DIR/nvm.sh" >/dev/null 2>&1
fi

# Last resort: add the newest nvm-managed Node bin directly.
if ! command -v node >/dev/null 2>&1; then
  latest_nvm_node="$(ls -d "$NVM_DIR"/versions/node/*/bin 2>/dev/null | sort -V | tail -1)"
  [ -n "$latest_nvm_node" ] && export PATH="$latest_nvm_node:$PATH"
fi

if ! command -v node >/dev/null 2>&1; then
  echo "Couldn't find Node.js from this launcher."
  echo ""
  echo "If you just installed it, open Terminal and run:  which node"
  echo "Then send that path along and the launcher can be pointed at it."
  echo ""
  echo "If that prints nothing, install Node from https://nodejs.org and retry."
  open "https://nodejs.org/en/download/"
  echo ""
  echo "Press any key to close."
  read -n 1 -s
  exit 1
fi

echo "Using Node $(node --version)"

# 2. Install dependencies the first time only.
if [ ! -d "node_modules" ]; then
  echo "First run: installing dependencies (one time, ~30s)..."
  npm install --no-audit --no-fund || {
    echo ""
    echo "Install failed. Check your internet connection and try again."
    echo "Press any key to close."
    read -n 1 -s
    exit 1
  }
fi

# 3. Start. This window stays open while the controller runs.
echo ""
echo "Starting. Leave this window open during the show."
echo "The operator panel is at http://127.0.0.1:4466"
echo "Close this window to stop the controller."
echo "-----------------------------------------------"
echo ""
node src/index.js
