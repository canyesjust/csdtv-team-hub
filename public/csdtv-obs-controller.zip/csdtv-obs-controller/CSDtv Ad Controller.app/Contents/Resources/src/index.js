// Entry point. Wires the OBS connection, the rotator module, and the web panel
// together. Add future modules (scheduler, graphics) right here.

import fs from 'node:fs';
import { ObsClient } from './obs.js';
import { Rotator } from './rotator.js';
import { HubSync } from './sync.js';
import { startServer } from './server.js';

// config.json lives next to the app (the current working directory the launcher
// sets), so the operator-facing files stay at the top level while the code is
// tucked inside the app bundle.
import path from 'node:path';
const configPath = path.resolve(process.cwd(), 'config.json');
const cfg = JSON.parse(fs.readFileSync(configPath));

// Persist config changes made from the panel's Settings.
function saveConfig() {
  fs.writeFileSync(configPath, JSON.stringify(cfg, null, 2) + '\n');
}

// Simple shared log buffer the panel can read.
const buffer = [];
const log = {
  add(msg) {
    const line = { time: new Date().toLocaleTimeString(), msg };
    buffer.push(line);
    if (buffer.length > 100) buffer.shift();
    console.log(`[${line.time}] ${msg}`);
  },
  recent() {
    return buffer.slice(-30);
  },
};

const obs = new ObsClient(cfg);
obs.on('log', m => log.add(m));

const rotator = new Rotator(cfg, obs);
rotator.on('log', m => log.add(m));

const sync = new HubSync(cfg, rotator);
sync.on('log', m => log.add(m));

startServer(cfg, rotator, log, sync, saveConfig);

await obs.connect();
if (cfg.autoStart) rotator.setAuto(true);

// Keep the local ad folder current with the hub.
if (cfg.autoSyncOnStart !== false) {
  sync.run('missing');
} else {
  sync.checkHub(); // at least show how many are waiting
}
const everyMin = Number(cfg.autoSyncEveryMin || 0);
if (everyMin > 0) {
  setInterval(() => sync.run('missing'), everyMin * 60 * 1000);
}
