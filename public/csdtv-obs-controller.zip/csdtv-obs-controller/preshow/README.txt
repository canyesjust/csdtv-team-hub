Put your "Starting Soon" hold video here, then click Reload folder.
