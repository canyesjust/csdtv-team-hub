Put your "Starting Soon" hold video in this folder (mp4 works best).
The controller loops the first video it finds here as the pre-show screen.
Only one video is used. If you drop several, it uses the first alphabetically.
