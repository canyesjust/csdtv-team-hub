# CSDTV OBS Controller

Plays a random ad (video or image) from a folder at random intervals, controlled
from an operator panel that docks inside OBS. The controller runs as a small Node
service on the streaming Mac and drives OBS over its built-in WebSocket. OBS plays
the files off the local disk.

This is the foundation. The ad rotator is the first module. A scheduler, graphics
triggers, and other automations drop in next to it and share the same OBS
connection.

## What you need

- OBS 28 or newer (WebSocket is built in)
- Node.js 18 or newer (install once from https://nodejs.org)
- A folder of ad files (mp4 for video, png/jpg for images)

## One-time setup

### 1. Turn on the OBS WebSocket

In OBS: **Tools → WebSocket Server Settings**. Check **Enable WebSocket server**.
Note the port (default 4455) and set a password if you want one.

### 2. Add the ad sources in OBS

In the scene that should show ads, add two sources:

- A **Media Source** named exactly `Commercials` (for video ads). Leave "Local
  File" empty. The controller fills it in.
- An **Image Source** named exactly `CommercialsImage` (for image ads). Leave the
  file empty too.
- A **Media Source** named exactly `StartingSoon` (for the pre-show hold video).
  Leave the file empty. Put it **below** the two ad sources in the scene list so
  ads cover it when they play.

Size and position them where you want ads to appear. If you only ever run video
ads, you can skip the image source and delete `imageSource` from `config.json`.
If you won't use the pre-show, you can skip `StartingSoon`.

### 3. Configure the controller

Open `config.json` and set:

- `obs.password` — your WebSocket password (the shared CSDtv password)
- `hubBaseUrl` — the hub address for downloading commercials (default
  `https://www.csdtvstaff.org`)
- `hubPassword` — password for the hub download page. Leave `""` and it reuses
  `obs.password`, since they're the same shared password.
- `scene` — the **exact** name of the scene holding the ad sources (default `Live`).
  This has to match your scene name or the ads load but stay hidden.
- `mediaSource` — the Media Source name (default `Commercials`)
- `imageSource` — the Image Source name (default `CommercialsImage`)
- `startingSoonSource` — the pre-show hold source name (default `StartingSoon`)
- `adFolder` — path to your ad files (default `./ads`)
- `preshowFolder` — path to your Starting Soon video (default `./preshow`)
- `minGapSec` / `maxGapSec` — shortest and longest wait between ads in auto mode
- `preshowMinGapSec` / `preshowMaxGapSec` — ad gap during pre-show (default 60/120s)
- `imageDurationSec` — how long an image ad stays on screen (default 12s)
- `autoStart` — start the rotation loop the moment the controller launches
  (default `false`, so nothing airs until you turn Auto on or hit Play)

### 4. Start it (Mac)

Double-click **CSDtv Ad Controller** — the app with the CSDtv icon. It starts the
controller in the background and opens the Ad Control panel in your browser. No
Terminal window. To stop it, quit the app.

The first time, macOS may say it's from an unidentified developer. **Right-click
it → Open → Open.** You only do that once. After that a plain double-click works.

The app carries its own dependencies, so it starts instantly with no install and
works offline. (`Start Ad Controller.command` is a fallback that runs it in a
Terminal window with a visible log, handy if you ever need to debug.)

First launch installs what it needs (about 30 seconds), then starts. A small
window opens and stays open while the controller runs. Leave it open during the
show. Closing it stops the controller.

You'll see `Operator panel at http://127.0.0.1:4466` when it's ready.

### 5. Dock the panel inside OBS

In OBS: **Docks → Custom Browser Docks**. Add one:

- **Dock Name:** Ad Control
- **URL:** `http://127.0.0.1:4466`

Click Apply. The panel appears as a dock you can drag anywhere. You can also open
that URL on a second monitor, tablet, or phone on the same network by swapping
`127.0.0.1` for the Mac's IP address.

## Using it

There are two ways to run ads.

**Click an ad to air it.** Every file in the `ads/` folder shows as a button in
the panel. Click one and it plays immediately. Good for airing a specific spot on
cue.

**Starting Soon pre-show.** Click **Start pre-show**. Your Starting Soon video
loops as the hold screen and ads drop in over it at random, every 1&ndash;2
minutes. When an ad finishes it clears and the hold video is still going
underneath. Click **Stop pre-show** to end it.

**Commercials from the hub.** Click **Download missing** and the controller pulls
every commercial from the hub straight into the `ads/` folder, then reloads. No
downloading and moving files by hand. **Download all** re-fetches everything. The
status line shows how many are local and whether new ones are waiting on the hub.
By default it also runs Download missing automatically each time it launches, so
the ads stay current on their own. These use `hubBaseUrl` and the shared password.

**Settings.** Open **Settings** in the panel to change the ad gap, pre-show gap,
image duration, auto-start, and auto-download, no editing `config.json`. Saving
writes the config and applies immediately.

Other controls:

- **▶ Play random ad** — fire a random ad immediately (video or image)
- **■ Stop ad** — pull whatever ad is on air right now (leaves the pre-show running)
- **Auto rotation** — a plain random loop using the normal 3&ndash;10 min gap,
  separate from the pre-show
- **Reload folder** — pick up new files you dropped in without restarting

Video ads hide themselves when they finish. Image ads hide after
`imageDurationSec`. Between ads, the ad sources are hidden so nothing sits frozen
on your feed.

## Ad files

The easiest way to fill the `ads/` folder is **Download missing** in the panel,
which pulls the commercials from the hub for you. You can also drop video
(`.mp4`, `.mov`, `.mkv`, `.webm`, `.m4v`) and image (`.png`, `.jpg`, `.gif`,
`.webp`) files into `ads/` by hand, then hit **Reload folder**.

Put your **Starting Soon** hold video in the `preshow/` folder. The controller
loops the first video it finds there. If you drop several, it uses the first one
alphabetically. After adding or changing it, hit **Reload folder**.

## Project layout

```
config.json               settings
Start Ad Controller.command  double-click launcher (Mac)
src/index.js              wires everything together, add modules here
src/obs.js                all OBS websocket calls
src/rotator.js            the ad rotator module (video + image)
src/server.js             serves the panel, API, and live status
public/index.html         the operator panel
ads/                      your ad files
```

## Auto-start at login (optional)

Most operators start the controller on purpose before a show, which is why it
doesn't auto-run. If you want it to launch automatically at login, that's a
LaunchAgent — ask and it can be added.

## Where this grows

- **Scheduler:** play certain ads in certain dayparts, cap frequency per hour
- **Graphics triggers:** fire lower thirds or scene changes with an ad
- **Play logs:** record what aired and when for reporting
- **Playlist / weighting:** favor some ads over others

Each is a new module in `src/` that reuses `ObsClient`. None of them touch OBS
internals, so OBS updates won't break them.
