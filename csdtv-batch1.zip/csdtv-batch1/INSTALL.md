# CSDTV Batch 1 — Cosmetic fixes for control surface

Fixes the agenda spacing bug ("3.AWelcome" → "3.A Welcome" rendered as a card),
adds the "ON AIR · ITEM X.Y · ACTION" eyebrow on the on-air card, and
restructures the header to match the mockup (LIVE pill + attendance text +
Mark attendance button row).

Nothing functional changes. No new props, no new data fetches, no new API calls.
Pure visual.

## Files in this zip

```
app/dashboard/board-meetings/[productionId]/control/components/AgendaPanel.tsx
app/dashboard/board-meetings/[productionId]/control/components/OnAirCard.tsx
app/dashboard/board-meetings/[productionId]/control/ControlSurfaceView.tsx
app/control/control-surface.css
```

## Install

After extracting the zip into the repo root, paste each file in this order:

```bash
code app/dashboard/board-meetings/\[productionId\]/control/components/AgendaPanel.tsx
code app/dashboard/board-meetings/\[productionId\]/control/components/OnAirCard.tsx
code app/dashboard/board-meetings/\[productionId\]/control/ControlSurfaceView.tsx
code app/control/control-surface.css
```

For each: select all → delete → paste the contents from the extracted zip → save.

Then commit and push:

```bash
git add .
git commit -m "control surface batch 1: cosmetic — agenda cards, onair eyebrow, header restructure"
git push
```

## What to look for on the deployed page

- Agenda items render as cards with: small checkbox icon · item number · title stacked
- Current item is highlighted red with "3.B · ON AIR" prefix
- On Air card shows a pulsing red dot + "ON AIR · ITEM X.Y" + action/recognition badge + larger title
- Header has 3 rows: breadcrumbs / "Control surface · Board Meeting" / [LIVE pill] [X present · quorum met] [Mark attendance]

## What is NOT in this batch (deferred)

- Lower-third first-name picker with Leon, McKay, "Other"
- QR push redesign (templates + modal)
- Motion & vote card empty state
- Consent block grouping (touches jump behavior — not cosmetic)
